var configServer ={};

configServer.mongodbURL = 'mongodb://localhost/birthapp';
configServer.emailProvider = 'hotmail';
configServer.emailUser = 'arodrigueze@psl.com.co';
configServer.emailPass = '';

module.exports = configServer;